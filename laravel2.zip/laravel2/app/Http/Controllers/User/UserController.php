<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mockery\Expectation;
use Illuminate\Session;
use App\Providers\conection; 
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use \stdClass;
use DateTime;

class UserController extends Controller
{
    
    use conection;
    //////////////////////inicio//////////////
    public function inicio(Request $request){
       return view('actividad/inicio'); 
   }

   public function encender_velas(Request $request){

        $tipo_vela=DB::select("SELECT * from tipo_vela");
        $peticionm_vela=DB::select("SELECT * from peticionm_vela");
        $color_vela=DB::select("SELECT * from color_vela");


       return view('entel/encender_velas',['tipo_vela'=>$tipo_vela, 'peticionm_vela'=>$peticionm_vela, 'color_vela'=>$color_vela]); 
   }



}