<?php

namespace App\Http\Controllers\User;

use App\User;
use Illuminate\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Session;
use App\Providers\conection; 

class AuthController extends Controller
{
    //
    use conection; 

    public function login(Request $request){
        return redirect('/');

    }

      //////logout///////////
      public function logout(Request $request){
        $request->session()->flush();
        return redirect('/');

    }


}
