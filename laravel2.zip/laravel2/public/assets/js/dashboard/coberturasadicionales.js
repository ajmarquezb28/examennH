var ruta = $('meta[name="base_url"]').attr('content') + '/';

$(document).ready(beneficios);

var idbeneficio;

function beneficios(){

    $.ajax({
        'url': "getCoberturasAdicionalies",
        beforeSend: function() {
            $("#content_beneficios").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    

        },
        'success': function(data) {
            obj = JSON.parse(data);
            var beneficios = "";

            if(idbeneficio == undefined){
                beneficios += `
                <div class="col-md-12">
                    <div id="titulo2">` + obj.data[0].titulo + `</div>
                </div>
                <div class="col-md-12">
                    <div id="text_pregunta">` + obj.data[0].contenido + `</div>
                </div>
            
                  
            
                `;
            }
            
         
            $.each(obj.data, function(i, value) {
                
                    if(idbeneficio==value.idbeneficio){
                        beneficios += `
                            <div class="col-md-12">
                                <div id="titulo2">` + value.titulo + `</div>
                            </div>
                            <div class="col-md-12">
                                <div id="text_pregunta">` + value.contenido + `</div>
                            </div>
                           
                           
                            `;
                    }
            })
            $('#content_beneficios').html(beneficios);
        }
    })

    
}


$('.select_cobertura').click(function() {
    var $items = $('.select_cobertura');
    $items.removeClass('activar_cobertura');
    $(this).addClass('activar_cobertura');

    idbeneficio = $(this).attr("idbeneficio");


    $(document).ready(beneficios);

})

