$(".custom-file-input").on("change", function() {
    var fileName = $(this).val().split("\\").pop();
    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});

var ruta = $('meta[name="base_url"]').attr('content') + '/';




$('#enviar').click(function() {



    if (!$("#de").val() || !$("#para").val() || ! $('#imagen')[0].files[0]) {
            
        $(".alerta").css("display", "block");
        $('#error1').text("Debe completar todos los campos");

    } else {
        $(".alerta").css("display", "none");
        return enviar_descanso();

    }

})


///////////funcion enviar descanso///////////////
 
function enviar_descanso(){

    var de = $("#de").val();
    var para = $("#para").val();
    //var archivo = document.getElementById("archivo").files[0].name; 
    var mensaje = $("#mensaje").val();
    var inputFileImage = document.getElementById("imagen");
    var imagen = inputFileImage.files[0];
    
    console.log(imagen);

    $.ajaxSetup(
        {
            headers:
            {
                'X-CSRF-Token': $('input[name="_token"]').val()
            }
    });

   

    var data = new FormData();
    data.append('de',de);
    data.append('para',para);
    data.append('mensaje',mensaje);
    data.append("imagen", imagen);


                
    $.ajax({
        enctype: 'multipart/form-data',
        url: ruta+'enviar_descanso_medico',        
        type: "POST",            
        data: data, 
        beforeSend: function() {     
            $(".spinner-border").fadeIn(200);　
        },			
        processData: false,
        contentType: false,
    

    }).done( function(data) {
        $(".spinner-border").hide();　
        ohSnap('Mensaje Enviado', {color: 'green'});
    
    }).fail( function(data) {
    
        ohSnap('No se pudo enviar el mensaje', {color: 'red'});
    
    
    }) 
}


   
 
  

