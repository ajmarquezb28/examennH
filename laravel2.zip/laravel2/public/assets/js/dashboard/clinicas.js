
var ruta = $('meta[name="base_url"]').attr('content') + '/';

var pagina = 0;

var lat = -12.122719;
var lng = -77.022874;
var search;

var request = null;



function sdf() {
    search = document.getElementById("search").value;
    if (request && request.readyState != 4) {
        request.abort();
    }

    console.log('entra');

    if(search !=""){
        proveedores();
        
    }else{
        setTimeout(function(){request.abort();}, 1000);

       

    
    }                                                                                                                                                                                                                                         


}

function proveedores(){
    
    var idservicio = $("#idservicio").val();

    if(pagina == undefined){

        pagina = 1;
    }

    if(search == undefined){

        search = -1;
    }
    

    request =$.ajax({
        'url': ruta + "proveedores_filtro",
        'data': { 'idservicio': idservicio,'lat':lat,'lng':lng,'pagina':pagina,'query':search},
        beforeSend: function() {
            $("#content_coberturas").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
      

        },
        'success': function(data) {

              obj = JSON.parse(data);
              console.log(obj);

              for (var i = 0, len = obj.length; i < len; i++) {
                console.log(obj.data[i]);
            }

            data = obj['data'];

            if(data != ''){

                var content_coberturas = "";

                $.each(data, function(i, value) {

                    content_coberturas += `

                    <div class="col-md-6">
                        <a href="detalle_clinica?idproveedor=` + value.idproveedor + `">
                            <div id="box">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div id="text_1"> ` + value.proveedor + `</div>
                                        <div id="text_2"> `  + value.direccion +  `</div>
                                        <div><i class="fas fa-phone-alt" id="tlf"></i> <span id="text_3"> ` + value.telefono + `</span></div>
                                    </div>
                                    <div class="col-md-4 text-right">
                                        <div id="like"><i class="far fa-thumbs-up"></i>  ` + value.calificaciones + `</div>
                                        <div><span id="precio"> ` + value.precio + `</span></div>
                                    </div>                                              
                                </div>
                            </div>
                        </a>
                    </div>`;

                })
                $('#content_coberturas').html(content_coberturas);
                $('#mostrar_mas').show();


            }else{

                var content_coberturas = '<div class="col-md-12 text-center" id="result_notfound">No se encontraron resultados.</div>';

                $("#content_coberturas").html(content_coberturas);
                $('#mostrar_mas').hide();

            }



        }

    })
}


//////funcion ver más////////////
function verMas(){

    pagina = parseInt(pagina) + 1;

    proveedores();

}


