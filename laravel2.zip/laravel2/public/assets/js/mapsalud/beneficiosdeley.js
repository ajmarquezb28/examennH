
var idcatbeneficioley;
var idOne = $("#idOne").val();
$('.select_cobertura').click(function() {
    var $items = $('.select_cobertura');
    $items.removeClass('activar_cobertura');
    $(this).addClass('activar_cobertura');
    idcatbeneficioley = $(this).attr("idcatbeneficioley");
    beneficio();
})
beneficio();

function beneficio(){

    if(idcatbeneficioley == undefined){

        idcatbeneficioley = idOne;
    }

    $.ajax({
        'url': "getBeneficioLey",
        'data':{'idcatbeneficioley':idcatbeneficioley},
        beforeSend: function() {
            $("#content_beneficios").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
        },
        'success': function(data) {
            obj = JSON.parse(data);
            var content = "";
            $.each(obj.data, function(i, value) {
                    content += `
                        <div class="col-md-12">
                            <p id="text_pregunta">- ` + value.beneficio + `</p>
                        </div>
                    `;
                
            })
       
            $('#content_beneficios').html(content);
        }
    })
}