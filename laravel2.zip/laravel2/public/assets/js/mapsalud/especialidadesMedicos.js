var ruta = $('meta[name="base_url"]').attr('content') + '/';


function basePath() {
    var scripts = document.getElementsByTagName("script");
    var urlPath = scripts[scripts.length - 1].src;
    return urlPath.substring(0, urlPath.indexOf('/assets'));
}

let base_path = basePath();

$(document).ready(mostrar_especialidad);  


//----------------------------------------------------buscar especialidad-------------------------------------

$('#boton_buscar').click(function() {

    if (!$('#select_especialidad').val()) {
        $(".alerta").css("display", "block");
        $('#error1').text("Seleccione una Especialidad");

    } else {
        $(".alerta").css("display", "none");
        return mostrar_especialidad();

    }
})


//----------------------------------------------------mostrar especialidad-------------------------------------


function mostrar_especialidad() {

    var idespecialidad = $('#select_especialidad').val();
    if(idespecialidad == null){

        var idespecialidad = 1;
    }

    $.ajax({
        'url': "medicoFiltro",
        'data': { 'idespecialidad': idespecialidad},
        beforeSend: function() {
            $("#content_especialidad").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
    
        },
        'success': function(data) {
    
            obj = JSON.parse(data);
          
            var content_especialidad = "";
    
            if (obj.status == 200) {
    
                for (var i in obj.data) {
                    for (var y in obj.data[i].clinicas) {
    
                        content_especialidad += `

                        <div class="col-md-6">
                          
                                    <a href="HorarioDetalleMedico?idmedico=` + obj.data[i].cmp + `">
                                        <div  id="especialistas">
                                            <div class="row" >
                                            
                                                        <div class="col-md-2">
                                                                <img src="${base_path}/assets/images/mapsalud/perfil/perfil.svg" alt="MAPSALUD" class="img-fluid salud">

                                                            </div>
                                                            <div class="col-md-8">
                                                                <div id="text_contac1">` + obj.data[i].nombres + ` ` + obj.data[i].apellidos + `</div>
                                                                <div id="text_contact2">` + obj.data[i].especialidad + `</div>
                                                                <div id="text_contact3">` + obj.data[i].clinicas[y].proveedor + `</div>
                                                            
                                                            </div>
                                                            <div class="col-md-2">
                                                                    <div id="like"><i class="far fa-thumbs-up"></i> ` + obj.data[i].calificaciones + ` </div>

                                                            </div>
                                            
                                                </div>
                                            </div>
                                    </a>
                        </div>
        
                   
                        
                        `;
                    }
                }
                $('#content_especialidad').html(content_especialidad);
            } else {
    
                content_especialidad = `
            
                    <div class="col-md-12 text-center" id="result_notfound">
                    No se encontraron resultados.
                    </div>
               
                    `;
                $('#content_especialidad').html(content_especialidad);
    
            }
    
        }
    })
    

    
}