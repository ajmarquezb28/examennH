

var lat = -12.122719;
var lng = -77.022874;

$.ajax({
    'url': "proveedoresFiltro",
    'data': { 'lat': lat,'lng':lng },
    beforeSend: function() {
        $("#map").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    

    },
    'success': function(data) {

        obj = JSON.parse(data);

        console.log(obj);

        for (var i = 0, len = obj.data.length; i < len; i++) {}
        data = obj['data'];

    
            var locations = data;
            var map;
            var markers = [];

            function init() {
                map = new google.maps.Map(document.getElementById('map'), {
                    zoom: 12,
                    center: new google.maps.LatLng(-12.122719, -77.022874),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var num_markers = locations.length;
                for (var i = 0; i < num_markers; i++) {

                    var image = {
                        url: locations[i].logo, 
                        scaledSize : new google.maps.Size(40,50)
                    }

                    markers[i] = new google.maps.Marker({
                        position: { lat: parseFloat(locations[i].latitud), lng: parseFloat(locations[i].longitud) },
                        map: map,
                        html: locations[i].proveedor,
                        id: i,
                        icon: image,
                    });

                    google.maps.event.addListener(markers[i], 'click', function() {
                        var infowindow = new google.maps.InfoWindow({
                            id: this.id,
                            content: this.html,
                            position: this.getPosition()
                        });
                        google.maps.event.addListenerOnce(infowindow, 'closeclick', function() {
                            markers[this.id].setVisible(true);
                        });
                        this.setVisible(false);
                        infowindow.open(map);
                    });
                }
            }

            init();

    }

})



