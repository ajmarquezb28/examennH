//---------------------------------------------ubicacion de la clinica------------------------------
var ruta = $('meta[name="base_url"]').attr('content') + '/';


/* ------------------------------------------------PACH ASSETS----------------------------------------*/

function basePath() {
    var scripts = document.getElementsByTagName("script");
    var urlPath = scripts[scripts.length - 1].src;
    return urlPath.substring(0, urlPath.indexOf('/assets'));
}

let base_path = basePath();

var idproveedor = $('#idproveedor').val();



var detalles_proveedores;

$.ajax({
    'async': false,
    'global': false,
    'dataType': 'html',
    'url': "detalleProveedor",
    'data': { 'idproveedor': idproveedor},
    'success': function(data) {
        detalles_proveedores = JSON.parse(data);
      

    }
});

console.log(detalles_proveedores)


for (var i = 0, len = detalles_proveedores.data.length; i < len; i++) {}
data = detalles_proveedores['data'];


var locations = data;
var map;
var markers = [];

function init() {
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: new google.maps.LatLng(-12.122719, -77.022874),
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var num_markers = locations.length;
    for (var i = 0; i < num_markers; i++) {

        var image = {
            url: locations[i].logo, 
            scaledSize : new google.maps.Size(40,50)
        }
        markers[i] = new google.maps.Marker({
            position: { lat: parseFloat(locations[i].latitud), lng: parseFloat(locations[i].longitud) },
            map: map,
            html: locations[i].clinica,
            id: i,
            icon: image,
        });

        google.maps.event.addListener(markers[i], 'click', function() {
            var infowindow = new google.maps.InfoWindow({
                id: this.id,
                content: this.html,
                position: this.getPosition()
            });
            google.maps.event.addListenerOnce(infowindow, 'closeclick', function() {
                markers[this.id].setVisible(true);
            });
            this.setVisible(false);
            infowindow.open(map);
        });
    }
}

init();




$('.ubic').click(function() {
    var $items = $('.ubic');
    $items.removeClass('activar_ubic');
    $(this).addClass('activar_ubic');
    $("#content_map").css("display", "block");
    $("#content_coberturas").css("display", "none");


});




// ---------------------------------------------------------ubicacion----------------------------------------------------



$('#coberturas').click(function() {

    $("#content_map").css("display", "none");
    $("#content_coberturas").css("display", "block");

    var content_coberturas = "";

    for (var i in detalles_proveedores.data) {
        for (var j in detalles_proveedores.data[i].coberturas) {
            console.log('entra')
            content_coberturas += `
          
                    <div class="row" id="section-8-eps">
                        <div class="col-md-6 text-left">
                            <div id="text-eps-13">
                                ` + detalles_proveedores.data[i].coberturas[j].tipo + `
                            </div>
                        </div>
                        <div class="col-md-3 text-right">
                            <div id="text-eps-14">
                               ` + detalles_proveedores.data[i].coberturas[j].deducible + `
                            </div>
                        </div>
                        <div class="col-md-3 text-right">
                            <div id="text-eps-14">
                                ` + detalles_proveedores.data[i].coberturas[j].cubierto + `
                            </div>
                        </div>
                    </div>
                 `;
        }
    }



    $('#content_coberturas').html(content_coberturas);


});









//------------------------------like------------------------------
$('#like').click(function() {
    var idproveedor = $('#idproveedor').val();
    var prueba = $('#prueba').html();

    $.ajax({
        url: 'setLike',
        data: { 'idproveedor': idproveedor, 'tipo': 0 },
        success: function(response) {   

            obj = JSON.parse(response);

            if (obj.message == "like it") {
                var result = parseInt(prueba) + parseInt(1);
               
                $('#prueba').html(result);
                $("#like").css({ 'color': '#3366BB ' });

            } else {

                var result = parseInt(prueba) - parseInt(1);
                $('#prueba').html(result);
                $("#like").css({ 'color': '#484848 ' });


            }



        }

    }) 
})

//------------------------------commets------------------------------


$('.comentario').keypress(function(event) {
    if (event.which == 13) {
        enviar_comentario();
        $('input[type="text"]').val('');


    }
});

function enviar_comentario() {
    var comentario = $('.comentario').val();
    var idproveedor = $('#idproveedor').val();

    $.ajax({
        url: 'setComentario',
        data: { 'idproveedor': idproveedor, 'tipo': 0, 'comentario': comentario },
        success: function(response) {   

            obj = JSON.parse(response);

            window.setTimeout(commet, 1);



        }

    }) 

}

$(document).ready(commet);

function commet() {

    var idproveedor = $('#idproveedor').val();
    contador = 0;

    $.ajax({
        url: 'getComentario',
        data: { 'idproveedor': idproveedor, 'tipo': 0 },
        success: function(response) {   

            obj = JSON.parse(response);
    
            comment = "";
            $.each(obj.data, function(i, value) {
             contador++;

                comment += `
                        <div class="row comentFila">
                            <div class="col-md-3">
                                <img src="${base_path}/assets/images/mapsalud/perfil/perfil.svg"  class="img-fluid" id="user_img">
                            </div>
                            <div class="col-md-9">
                                <div id="text-eps-7">
                                    ` + value.nombre + `
                                </div>
                                <div id="text-eps-8">
                                    <small>` + value.comentario + `</small>
                                </div>
                            </div>
                        </div>
                    `;

            });

            $("#comment").html(comment);
            $('.comentarios').html(contador);

        }

    }) 
}



