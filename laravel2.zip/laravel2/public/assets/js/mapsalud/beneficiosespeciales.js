

$('.select_cobertura').click(function() {
    idbeneficio = $(this).attr("idbeneficio");
    var $items = $('.select_cobertura');
    $items.removeClass('activar_cobertura');
    $(this).addClass('activar_cobertura');
    $.ajax({
        'url': "getBeneficiosEspeciales",
        beforeSend: function() {
            $("#content_beneficios").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    

        },
        'success': function(data) {
            obj = JSON.parse(data);
            var preguntas = "";
            $.each(obj.data, function(i, value) {
                
                    if(idbeneficio==value.idbeneficio){
                        preguntas += `
                        <div class="col-md-12">
                            <div id="title_prinicipal">` + value.titulo + `</div>
                            <div id="text_pregunta">` + value.contenido + `</div>
                        </div>
                          
                           
                            `;
                    }
            })
       
            $('#content_beneficios').html(preguntas);
        }
    })

})