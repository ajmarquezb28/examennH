var ruta = $('meta[name="base_url"]').attr('content') + '/';


//////////var globales///////////
var pagina;
var lat = -12.122719;
var lng = -77.022874;
var idservicio;

$(document).ready(salud);  


function salud(){

    if(idservicio ==  undefined){

        idservicio = 1;
    }

    if(pagina ==  undefined){

        pagina = 1;
    }

    $.ajax({
        'url': "proveedoresFiltro",
        'data': { 'idservicio': idservicio,'lat':lat,'lng':lng,'pagina':pagina},
        beforeSend: function() {
            $("#content_coberturas").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
      

        },
        'success': function(data) {

              obj = JSON.parse(data);



           

            if(obj.data != ''){

                var content_coberturas = "";

                $.each(obj.data, function(i, value) {

                    content_coberturas += `

                    <div class="col-md-6">
                        <a href="detalleClinica?idproveedor=` + value.idproveedor + `">
                            <div id="box">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div id="text_1"> ` + value.proveedor + `</div>
                                        <div id="text_2"> `  + value.direccion +  `</div>
                                        <div><i class="fas fa-phone-alt" id="tlf"></i> <span id="text_3"> ` + value.telefono + `</span></div>
                                    </div>
                                    <div class="col-md-4 text-right">

                                        <div id="like"><i class="far fa-thumbs-up"></i> ` + value.calificaciones + `</div>
                                        <div><span id="precio"> ` + value.precio + `</span></div>
                                    </div>                                              
                                </div>
                            </div>
                        </a>
                    </div>`;

                })
                $('#content_coberturas').html(content_coberturas);
                $("#mostrar_mas").show();

            }else{

                var content_coberturas = '<div class="col-md-12 text-center" id="result_notfound">No se encontraron resultados.</div>';

                $("#content_coberturas").html(content_coberturas);
                $("#mostrar_mas").hide();
            }



        }

    })
    

}

//////funcion ver más////////////
function verMas(){

    pagina = pagina + 1;

    salud();

}


//---------------------selecccionar cobertura--------------------------

$('.select_cobertura').click(function() {
    var $items = $('.select_cobertura');
    $items.removeClass('activar_cobertura');
    $(this).addClass('activar_cobertura');

   idservicio = $(this).attr("idservicio");


    $(document).ready(salud);


})

