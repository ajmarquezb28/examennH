
var idcompensacion;
var idOne = $("#idOne").val();
$('.select_cobertura').click(function() {
    var $items = $('.select_cobertura');
    $items.removeClass('activar_cobertura');
    $(this).addClass('activar_cobertura');
    idcompensacion = $(this).attr("idcompensacion");
    compensacion();
})
compensacion();

function compensacion(){

    if(idcompensacion == undefined){

        idcompensacion = idOne;
    }

    $.ajax({
        'url': "getCompensacionesDetalle",
        'data':{'idcompensacion':idcompensacion},
        beforeSend: function() {
            $("#contenido").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
        },
        'success': function(data) {
            obj = JSON.parse(data);
            console.log(obj);
            var content = "";
            $.each(obj.data, function(i, value) {
                    content += `
                        <div class="col-md-12">
                            <div id="title_prinicipal">` + value.titulo + `</div>
                            <p id="text_pregunta">- ` + nl2br(value.contenido) + `</p>
                        </div>
                    `;
                
            })
       
            $('#contenido').html(content);
        }
    })
}


function nl2br(str) {
    return str 
      ? str.replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n|-)/g, '$1 <br /> $2')
      : '';
}