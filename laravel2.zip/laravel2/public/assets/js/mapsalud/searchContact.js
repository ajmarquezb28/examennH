var ruta = $('meta[name="base_url"]').attr('content') + '/';

var request = null;

function searchContact() {
    var query = $("#buscar").val(); //val of search bar
    var expression = new RegExp(query, "i");
    var contador=0;
    if (request && request.readyState != 4) {
        request.abort();
    }
    if(query !=""){
        request = $.ajax({                                   
            url: ruta + "contacto",
            beforeSend: function() {                           //cargando
                $("#infoContact").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
            },

            success: function(data) {       
                obj = JSON.parse(data);

               
                 var result = "";
                $.each(obj.data, function(key, value){
                    
                    if (value.texto.search(expression) != -1) {

                        contador++;
                        result += `
                            <div class="col-md-12">
                                <div class="boxContact">
                                        <div class="row">
                                            <div class="col-md-auto">
                                                <img class="img-fluid" src="` + value.imagen + `">
                                            </div>
                                            <div class="col-md-9">
                                                <div id="text66">` + value.nombre + `</div>
                                                <div id="name55">` + value.texto + ` </div>
                                                <div id="tel"> <i class="fas fa-phone-alt"> </i> ` + value.numero + `</div>
                                                <div id="email">` + value.email + `</div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        `;

                    }
                   
                });//end each
                    
                if(contador>0){
                    $("#infoContact").html(result);
                }else{
                    result = `
    
                    <div class="col-md-12 text-center" id="result_notfound">
                        No se encontraron resultados
                    </div>
                   
            
                    `;
                    $('#infoContact').html(result);
                }
 

                $("#buscar").css("background", "#fff");     

                                                             
            }              
        }); 
    }else{
        setTimeout(function(){request.abort();}, 1000);
    
    }                                                                                                                                                                                                                                         


}

