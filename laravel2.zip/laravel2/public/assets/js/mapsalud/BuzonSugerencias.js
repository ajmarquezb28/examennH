var ruta = $('meta[name="base_url"]').attr('content') + '/';

var de;
var mensaje;


$('#enviar').click(function() {

    de = $("#de").val();
    mensaje = $("#mensaje").val();

    if (!$("#de").val() ||	!$("#mensaje").val()) {
        ohSnap('Debe completar todos los campos', {color: 'red'});

    } else {
        return enviarSugerencia();

    }

})

 
function enviarSugerencia(){

  
    $.ajax({
        'url':  "sendSugerencia",
        'data': { 'de': de,'mensaje':mensaje},
        beforeSend: function() {     
            $(".spinner-border").fadeIn(200);　
        },	
       

    }).done( function(data) {

        console.log(data);
        $(".spinner-border").hide();　
        ohSnap('Mensaje Enviado', {color: 'green'});
    
    }).fail( function(data) {
    
        ohSnap('No se pudo enviar el mensaje', {color: 'red'});
    
    
    }) 
                
    
}

