//-----------------buscar-------------------------
$('#boton_buscar').click(function() {


    if (!$('#especialidad').val()) {
        $(".alerta").css("display", "block");
        $('#error1').text("Seleccione una Especialidad");
        return false;
    } else {
        
        var diaselecionado = $('#dia').val();
        var idespecialidad = $('#especialidad').val();
        var contador = 0;


        var idmedico = [];

        //especialidad
        $.ajax({
            'url': 'medicoFiltro',
            'data':{'idespecialidad':idespecialidad},
            beforeSend: function() {
                $("#content_horario").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    

            },
         
            'success': function(data) {
                especialidad = JSON.parse(data);
                
                $.each(especialidad.data, function(m, info) {

                    idmedico.push(info.cmp);

                })
                especialidadF(especialidad);

            }
        })
        console.log(idmedico);
        function especialidadF(especialidad) {
          
            if (especialidad.status != 200 ) {
                var content_horario = '<div class="col-md-12 text-center" id="result_notfound">No se encontraron resultados.</div>';

                $("#content_horario").html(content_horario);
            }else{

                $.ajax({
                    'url': "medicoDetalle",
                    'data':{idmedico:idmedico},
                    beforeSend: function() {
                        $("#content_horario").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    
    
                    },
                    'success': function(data) {
                        obj = JSON.parse(data);
                        var content_horario="";
                
                
                            $.each(obj, function(y, value) {
                                $.each(value, function(z, value2) {
                                    $.each(value2.horarios, function(y, value1) {
                                        var n=value1.horarios;
                                        var s=n.length
    
                                        if(s>0){
                                            $.each(value1.horarios, function(z, value3) {
                                                
                                                if (value3.dia == 0) {
                
                                                    var dia = 'Lunes';
                                                }
                                                if (value3.dia == 1) {
            
                                                    var dia = 'Martes';
                                                }
            
                                                if (value3.dia == 2) {
            
                                                    var dia = 'Miércoles';
                                                }
                                                if (value3.dia == 3) {
            
                                                    var dia = 'Jueves';
                                                }
                                                if (value3.dia == 4) {
            
                                                    var dia = 'Viernes';
                                                }
                                                if (value3.dia == 5) {
            
                                                    var dia = 'Sábado';
                                                }
    
                                                if(diaselecionado== -1){
    
    
                                                        content_horario += `
                                                        <div class="col-md-6">
                                                            <div id="box">
                                                                <div class="row">
                                                                    <div class="col-md-8">
                                                                        <div id="text_1"> ` + value2.nombres + ` ` + value2.apellidos + `</div>
                                                                        <div id="text_2"> ` + value2.especialidad + `</div>
                                                                        <div id="text_3">CMP. ` + value2.cmp + `</div>
                                                                        <div id="text_4">` + dia + `  ` + value3.hora_ini + ` - ` + value3.hora_fin + `</div>
                                                                    </div>
                                                                    <div class="col-md-4 text-right">
                                                                        <div id="like"><i class="far fa-thumbs-up"></i>  ` + value2.calificaciones + `</div>
                                                                    </div>                                              
                                                                </div>
                                                            </div>
                                                        </div>
                    
                                    
                                                        `; 
    
                                                }else{
    
                                                    if(value3.dia == diaselecionado){
                                                
                                                        if (diaselecionado == 0) {
                
                                                            var dia = 'Lunes';
                                                        }
                                                        if (diaselecionado == 1) {
                    
                                                            var dia = 'Martes';
                                                        }
                    
                                                        if (diaselecionado == 2) {
                    
                                                            var dia = 'Miércoles';
                                                        }
                                                        if (diaselecionado == 3) {
                    
                                                            var dia = 'Jueves';
                                                        }
                                                        if (diaselecionado == 4) {
                    
                                                            var dia = 'Viernes';
                                                        }
                                                        if (diaselecionado == 5) {
                    
                                                            var dia = 'Sábado';
                                                        }
                
                                                        content_horario += `
                                                        <div class="col-md-6">
                                                            <div id="box">
                                                                <div class="row">
                                                                    <div class="col-md-8">
                                                                        <div id="text_1"> ` + value2.nombres + ` ` + value2.apellidos + `</div>
                                                                        <div id="text_2"> ` + value2.especialidad + `</div>
                                                                        <div id="text_3">CMP. ` + value2.cmp + `</div>
                                                                        <div id="text_4">` + dia + `  ` + value3.hora_ini + ` - ` + value3.hora_fin + `</div>
                                                                    </div>
                                                                    <div class="col-md-4 text-right">
                                                                        <div id="like"><i class="far fa-thumbs-up"></i>  ` + value2.calificaciones + `</div>
                                                                    </div>                                              
                                                                </div>
                                                            </div>
                                                        </div>
                    
                                    
                                                        `; 
                                                    }
                                                }
    
                                            })
                                        }else{
    
                                           
                                                content_horario += `
                                                <div class="col-md-6">
                                                    <div id="box">
                                                        <div class="row">
                                                            <div class="col-md-8">
                                                                <div id="text_1"> ` + value2.nombres + ` ` + value2.apellidos + `</div>
                                                                <div id="text_2"> ` + value2.especialidad + `</div>
                                                                <div id="text_3">CMP. ` + value2.cmp + `</div>
                                                                <div id="text_4"> horario: No especificado</div>
                                                            </div>
                                                            <div class="col-md-4 text-right">
                                                                <div id="like"><i class="far fa-thumbs-up"></i>  ` + value2.calificaciones + `</div>
                                                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                `; 
                                          
                                        }
    
                                    
    
    
    
                                    })
                                    
                                })
                            
                            }) 
    
                        
            
                            $("#content_horario").html(content_horario);
            
                    
                    
                    
                    }
            })
            
            }   
            
            
        }
   
       
    
    }
})

