var ruta = $('meta[name="base_url"]').attr('content') + '/';


/* ------------------------------------------------PACH ASSETS----------------------------------------*/

function basePath() {
    var scripts = document.getElementsByTagName("script");
    var urlPath = scripts[scripts.length - 1].src;
    return urlPath.substring(0, urlPath.indexOf('/assets'));
}

let base_path = basePath();


$(document).ready(function() {

    $('#like').click(function() {
        var idmedico = $('#idmedico').val();
        var prueba = $('#prueba').html();

        $.ajax({
            url: 'setLike',
            data: { 'idmedico': idmedico, 'tipo': 1 },
            success: function(response) {   

                obj = JSON.parse(response);

                
                if (obj.message == "like it") {
                    var result = parseInt(prueba) + parseInt(1);
                
                    $('#prueba').html(result);
                    $("#like").css({ 'color': '#3366BB ' });

                } else {

                    var result = parseInt(prueba) - parseInt(1);
                    $('#prueba').html(result);
                    $("#like").css({ 'color': '#484848 ' });


                }





            }

        }) 
    })




});   

$('.comentario').keypress(function(event) {
    if (event.which == 13) {
        enviar_comentario();
        $('input[type="text"]').val('');


    }
});

function enviar_comentario() {
    var comentario = $('.comentario').val();
    var idmedico = $('#idmedico').val();

    $.ajax({
        url: 'setComentario',
        data: { 'idmedico': idmedico, 'tipo': 1, 'comentario': comentario },
        success: function(response) {   

            obj = JSON.parse(response);

            window.setTimeout(commet, 1);



        }

    }) 

}
$(document).ready(commet);


function commet() {

    var idmedico = $('#idmedico').val();
    contador = 0;

    $.ajax({
        url: 'getComentario',
        data: { 'idmedico': idmedico, 'tipo': 1 },
        success: function(response) {   

            obj = JSON.parse(response);

            comment = "";
            $.each(obj.data, function(i, value) {
                contador++;
                comment += `
                
               
                        <div class="row" id="section-4-eps">
                            <div class="col-md-3" >
                                <img src="${base_path}/assets/images/mapsalud/perfil/perfil.svg"  class="img-fluid" id="user_img">
                            </div>
                            <div class="col-md-9">
                                <div id="text-eps-7">
                                   ` + value.nombre + `
                                </div>
                                <div id="text-eps-8">
                                    <small>` + value.comentario + `</small>
                                </div>
                            </div>
                        </div>
              
               
            `;

            });

            $("#comment").html(comment);

            $('.comentarios').html(contador);

        }

    }) 
}
