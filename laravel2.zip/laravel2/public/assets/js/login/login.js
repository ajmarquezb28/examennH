var ruta = $('meta[name="base_url"]').attr('content') + '/';

//autocomple off
$(document).ready(function(){
    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });
});


///validar solo numeros
///validar solo numeros
function valideKey(evt) {
    var code = evt.which ? evt.which : evt.keyCode;
    if (code == 8) {
        //backspace
        return true;
    } else if (code >= 48 && code <= 57) {
        //is a number
        return true;
    } else {
        return false;
    }
}

$(document).on('keypress',function(e) {
    if(e.which == 13) {
        datosForm();
    }
});

//////////funcion datosForm///////////
function datosForm(){

    if(!$("#dni").val()){

        ohSnap('Debe ingresar el DNI', {color: 'red'});
        return false;

    }else{
        login();

    }
   
}

//login
$("#botonIngresar").click(function() {
    
    if(!$("#dni").val()){

        ohSnap('Debe ingresar el DNI', {color: 'red'});
        return false;

    }else{
        login();

    }
})



//funcion login

function login() {
    $('meta[name="base_url"]').attr("content");

    var e = $("input[name=_token]").val();
    dni = $("#dni").val();

    $.ajaxSetup(
        {
            headers:
            {
                'X-CSRF-Token': $('input[name="_token"]').val()
            }
    });

    $.ajax({
        'url': "login",
        "method": "POST",
        'data':{'dni':dni},
        beforeSend: function() {     
            $(".spinner-border").fadeIn(200);　
        },
        'success': function(e) {
 
          if(e.succes == 'OK'){

           
                location.href='inicio';
               
            }else{

                ohSnap('Ups! Si no puedes ingresar:<BR> Comunicate con  beneficiosviveentel@entel.pe', {color: 'red'});
                window.setTimeout(function(){window.location.href = "/"},4000);
 
            }   

        }
    })
}