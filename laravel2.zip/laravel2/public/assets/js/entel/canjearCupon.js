var ruta = $('meta[name="base_url"]').attr('content') + '/';

$('#botonSiguiente').click(function() {

    $('#contentCupon').hide();
    $('#contentCuponCanjear').show();



})

//////////////funcion de calendario//////////////

$(function () {
    

    $('#datetimepicker1').datetimepicker({
        locale: 'es-es',
      
        format: 'YYYY-MM-DD'
    })


})

var fecha;
$("#datetimepicker1").on("change.datetimepicker", function (e) {
    fecha = document.getElementById("fecha").value;

})

///select turno
var value;
var name;
$('input:radio').on('change',function (e) {

    value = $(this).val();
    if(value == 0){

        name = "Mañana";

    }else{

        name = "Tarde";

    }

})


/////////canjear///////////bin
$('#canjear').click(function() {

    var mensaje = $("#msj").val();
    var idcupon = $("#idcupon").val();
    console.log(name);

    if(name == ""){
        name = "0";    
    }

    if(value == undefined){
        value = "0";    
    }
    if(mensaje == undefined){

        mensaje = "0";    
    }


    if(fecha == undefined){

        ohSnap('Debe ingresar la fecha', {color: 'red'});
        return false;

    }else{

        $.ajax({
            'url': ruta + "generar_peticion",
            'data': {'mensaje': mensaje,'idcupon':idcupon,'fecha':fecha,'name':name,'value':value},
            beforeSend: function() {     
                $(".spinner-border").fadeIn(200);　
            },
            'success': function(data) {
        
                obj = JSON.parse(data);
                if(obj.status == 200){

                    ohSnap('El cupon se ha generado', {color: 'green'});
                }else{

                    ohSnap('Ocurrió un error', {color: 'red'});
                }
    
            }
    
        }) .done(function() {
            $("#spiner").hide();
          })

    }

   


})