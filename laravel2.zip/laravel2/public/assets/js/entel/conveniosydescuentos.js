var ruta = $('meta[name="base_url"]').attr('content') + '/';

var tipo;

$('.select_bene').click(function() {
    
    tipo = $(this).attr("tipo");

    $(document).ready(convenios_detalle);  


});

$(document).ready(convenios_detalle);  


function convenios_detalle(){

   if(tipo == undefined){

        tipo =1;
   }
    $.ajax({
        'url': "getConvenio",
        beforeSend: function() {
            $("#content_convenio").html("<div class='spinner-border cargando' style='margin-right:10px;' role='status'> </div> Espere un momento por favor");                    

        },
        'success': function(data) {

              obj = JSON.parse(data);
           

               var content_convenio = "";
                $.each(obj.data, function(i, value) {
                    if(value.tipo == tipo){
                        $.each(value.detalle, function(y, item) {
                            content_convenio += `
                            <div class="col-md-3">
                                <div class="box_conv" data-toggle="modal" data-target="#myModal" id="` + item.id + `" >
                                    <div class="text-center" id="img_conv">
                                    <img src="` + item.imagen + `" alt="convenios educativos" class="img-fluid img_convenio">
                                    </div>
                                    <div class="text-center" id="text_convenio">
                                    ` + item.titulo + `
                                    </div>
                                </div>
                            </div>
                        
                                        `;
                        })

                    }
             
                });
                $('#content_convenio').html(content_convenio);

                $(".box_conv").click(function() {

                    var idconvenio = $(this).attr("id");

                    var content_modal = "";
                    $.each(obj.data, function(i, value) {
                        if(value.tipo == tipo && tipo == 1){
                            $.each(value.detalle, function(y, info) {

                                if (info.id == idconvenio) {

                                    function nl2br(str) {
                                        return str 
                                          ? str.replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1 <br /> $2')
                                          : '';
                                      }
    
                                    content_modal += `
                                        <div class="text-center">
                                            <img src="` + info.imagen + `" alt="convenios educativos" class="img-fluid img_convenio">

                                        </div>
                                        <div id="universidad_3">
                                            ` + nl2br(info.detalle_convenio) + `
                                        </div>
                                        <div id="contacto">Contacto:</div>
                                        `;
                                  
                                    $.each(info.contactos, function(x, item) {
                                        
                                        if(item.nombres == "-" || item.nombres == "- "  || item.nombres == ""){

                                            var nombres="";
                                        }else{

                                            var nombres=item.nombres;
                                        }

                                        if(item.cargo == "-" || item.cargo == "- "  || item.cargo == ""){
    
                                            var cargo="";
                                        }else{

                                            var cargo=item.cargo;
                                        }

                                        if(item.direccion == "-" || item.direccion == "- "  || item.direccion == ""){
    
                                            var direccion="";
                                        }else{

                                            var direccion=item.direccion;
                                        }

                                        if(item.telefono == "-" || item.telefono == "- "  || item.telefono == "" || item.telefono == undefined){
    
                                            var telefono="";
                                        }else{

                                            var telefono=item.telefono;
                                        }

                                        if(item.link == "-" || item.link == "- " || item.link == ""){
    
                                            var link="";
                                        }else{

                                            var link=item.link;
                                        }
                                        content_modal += `
                                            <div id="content_contacto"> ` + nombres + `</div>
                                            <div id="content_contacto"> ` + cargo + `</div>
                                            <div id="content_contacto"> ` + direccion + `</div>
                                            <div id="content_contacto"> ` + telefono + `</div>
                                            <a href="` + link + `" target="_blank" id="content_contacto"> ` + link + `</a>
                                        `;
                                    })
                                    if(info.vigencia == "-" || info.vigencia == "- " || info.vigencia == "" || info.vigencia == undefined){
    
                                        var vigencia="";
                                    }else{

                                        var vigencia=info.vigencia;
                                    }
                                    content_modal += `
                                    <div id="content_valides">
                                        ` + vigencia + `
                                    </div>
                                    `;
                                    
                                }
                            })
                        }
                        if(value.tipo == tipo && tipo == 2){
                            $.each(value.detalle, function(y, info) {

                                if (info.id == idconvenio) {

                                    function nl2br(str) {
                                        return str 
                                          ? str.replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1 <br /> $2')
                                          : '';
                                      }
    
                                    content_modal += `
                                        <div class="text-center">
                                            <img src="` + info.imagen + `" alt="convenios educativos" class="img-fluid img_convenio">

                                        </div>
                                        <div id="universidad_3">
                                            ` + nl2br(info.descripcion) + `
                                        </div>
                                        `;
                                    
                                        $.each(info.contacto_lista, function(x, item) {
                                        
                                            if(item.tipo != 1){
                                                content_modal += `
                                                    <div id="content_contacto"> ` + titulo + ` : ` + nombres + `</div>
                                                
                                                `;
                                            }else{
                                                content_modal += `
                                                <a href="` + item.link + `" target="_blank" id="content_contacto"> ` + item.link + `</a>
                                            
                                            `;
                                            }

                                        })
                                    content_modal += `
                                    <div id="content_valides">
                                        ` + info.vigencia + `
                                    </div>
                                    `;


                                }
                            })

                        }

                    })

                    $('#content_modal').html(content_modal);


                }); 

 
        }

    })
}
