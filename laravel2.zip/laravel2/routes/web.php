<?php

use Illuminate\Support\Facades\Route;
use App\Providers\conection; 
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $categoria=DB::select("SELECT * from categoria");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas");
                $cat->tareas=$tareas;

    }

    return view('actividad/inicio');
});

Route::get('inicio', function () {

    $categoria=DB::select("SELECT * from categoria");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/inicio',['categoria'=>$categoria]);
});

Route::post('tareas', function (Request $request) {

    $categoria=DB::select("SELECT * from categoria where id ='".$request['id']."'");

    if(count($categoria)==0 || count($categoria)>1){

        $categoria=DB::select("SELECT * from categoria");

        foreach ($categoria as $cat) {

                    $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                    $cat->tareas=$tareas;

        }

        return view('actividad/inicio',['categoria'=>$categoria]);
    }

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/tareas',['categoria'=>$categoria]);
});

Route::get('categorias', function () {

    $categoria=DB::select("SELECT * from categoria");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/categorias',['categoria'=>$categoria]);
});


Route::post('actualizarc', function (Request $request) {

    $cat=DB::update("update `categoria` set `nombre`='".$request['nombre']."', `descripcion`='".$request['descripcion']."' WHERE id='".$request['id']."'");

    $categoria=DB::select("SELECT * from categoria");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/categorias',['categoria'=>$categoria]);
});

Route::post('actualizart', function (Request $request) {

    $cat=DB::update("update `tareas` set `nombre`='".$request['nombre']."', `descripcion`='".$request['descripcion']."', `tipo`='".$request['tipo']."', `observaciones`='".$request['observaciones']."', `nivel`='".$request['nivel']."' WHERE id='".$request['id']."'");

    $categoria=DB::select("SELECT * from categoria where id ='".$request['id_categoria']."'");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/tareas',['categoria'=>$categoria]);
});

Route::post('eliminarc', function (Request $request) {

    $cat=DB::delete("delete from `categoria` WHERE id='".$request['id']."'");

    $categoria=DB::select("SELECT * from categoria");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/categorias',['categoria'=>$categoria]);
});

Route::post('eliminart', function (Request $request) {

    $cat=DB::delete("delete from `tareas` WHERE id='".$request['id']."'");

    $categoria=DB::select("SELECT * from categoria where id ='".$request['id_categoria']."'");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/tareas',['categoria'=>$categoria]);
});

Route::post('agregarc', function (Request $request) {

    $cat=DB::insert("INSERT INTO `categoria`(`nombre`, `descripcion`) VALUES ('".$request['nombre']."', '".$request['descripcion']."')");

    $categoria=DB::select("SELECT * from categoria");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/categorias',['categoria'=>$categoria]);
});


Route::post('agregart', function (Request $request) {

    $cat=DB::insert("INSERT INTO `tareas`(`nombre`, `descripcion`, `observaciones`, `tipo`, `nivel`, `id_categoria`) VALUES ('".$request['nombre']."', '".$request['descripcion']."', '".$request['observaciones']."', '".$request['tipo']."', '".$request['nivel']."', '".$request['id']."')");

    $categoria=DB::select("SELECT * from categoria where id ='".$request['id']."'");

    foreach ($categoria as $cat) {

                $tareas=DB::select("SELECT * from tareas where id_categoria ='".$cat->id."'");
                $cat->tareas=$tareas;

    }

    return view('actividad/tareas',['categoria'=>$categoria]);
});
