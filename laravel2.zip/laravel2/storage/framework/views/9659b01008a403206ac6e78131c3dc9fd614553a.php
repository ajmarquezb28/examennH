
<link href="<?php echo e(URL::asset('/assets/css/actv/inicio.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<?php $__env->startSection('content'); ?>
        <?php
                $page ='inicio';
        ?>

        <!-- LAST SERMON SECTION STARTS -->
      <section class="default-section-spacing">

        <div class="container">

          <div class="row align-items-center">

            <div class="flex-md-12 flex-lg-12" align="center">

              <h2>Administracion de datos de las actividades</h2>

                <table class="table-responsive  table-sm">                
                      <tbody>
                        <tr class="table-warning">
                          <th scope="col" colspan="5">Categorías</th>
                        </tr>
                        <tr class="table-info">
                          <th scope="col">#</th>
                          <th scope="col">Nombre</th>
                          <th scope="col" colspan="2">Descripcion</th>
                          <th scope="col">Fecha</th>
                        </tr>
                      <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr class="table-success">
                          <th scope="row"><?php echo e($item->id); ?></th>
                          <td><?php echo e($item->nombre); ?></td>
                          <td colspan="2"><?php echo e($item->descripcion); ?></td>
                          <td><?php echo e($item->fecha_creacion); ?></td>
                        </tr>
                        <tr class="table-warning">
                          <th scope="col">Nombre</th>
                          <th scope="col">Tipo</th>
                          <th scope="col">Descripcion</th>
                          <th scope="col">Observaciones</th>
                          <th scope="col">Nivel</th>
                          <th scope="col">Fecha</th>
                        </tr>
                        <?php $__currentLoopData = $item->tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-danger">
                          <td><?php echo e($values->nombre); ?></td>
                          <td><?php echo e($values->tipo); ?></td>
                          <td><?php echo e($values->descripcion); ?></td>
                          <td><?php echo e($values->observaciones); ?></td>
                          <td><?php echo e($values->nivel); ?></td>
                          <td><?php echo e($values->fecha_creacion); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                </table><br><br><br>
                
              </div><!-- . ends -->

            </div><!-- .flex-* ends -->

          </div><!-- .row ends -->

        </div><!-- .container ends -->

      </section>
      <!-- SECTION ENDS -->

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel2\laravel2\resources\views/actividad/inicio.blade.php ENDPATH**/ ?>