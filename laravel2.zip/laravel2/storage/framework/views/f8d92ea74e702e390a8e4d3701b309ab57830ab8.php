
<link href="<?php echo e(URL::asset('/assets/css/actv/inicio.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<?php $__env->startSection('content'); ?>
        <?php
                $page ='inicio';
        ?>

        <!-- LAST SERMON SECTION STARTS -->
      <section class="default-section-spacing">

        <div class="container">

          <h2>Categoría: <?php echo e($categoria[0]->nombre); ?></h2>


          <form action="agregart" enctype="multipart/form-data" method="POST">
                        <?php echo e(csrf_field()); ?>


            <div class="row align-items-center">
                     
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Nombre <span class="color-danger">*</span></label>
                              <input type="text" id="nomb" class="form__input" name="nombre"  placeholder="Nombre">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Descripcion <span class="color-danger">*</span></label>
                              <input type="text" id="desc" class="form__input" name="descripcion"  placeholder="Descripcion">
                              <input type="hidden" id="id" class="form__input" name="id" value="<?php echo e($categoria[0]->id); ?>">

                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Tipo <span class="color-danger">*</span></label>
                              <input type="text" id="tip" class="form__input" name="tipo"  placeholder="Tipo">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Observaciones <span class="color-danger">*</span></label>
                              <input type="text" id="observaciones" class="form__input" name="observaciones"  placeholder="Observaciones">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Nivel <span class="color-danger">*</span></label>
                              <input type="text" id="niv" class="form__input" name="nivel"  placeholder="Nivel">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
        
                        <div class="flex-md-2">

                            <br><button class="button" type="submit" name="submit">Agregar Nueva</button>

                        </div><!-- .flex-* ends -->

                      </form> 
            </div>

              

                      <?php $__currentLoopData = $categoria[0]->tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <form action="actualizart" enctype="multipart/form-data" method="POST">
                        <?php echo e(csrf_field()); ?>


                        <div class="row align-items-center">
                     
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Nombre <span class="color-danger">*</span></label>
                              <input type="text" id="nomb" class="form__input" name="nombre" value="<?php echo e($item->nombre); ?>" placeholder="Nombre">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Descripcion <span class="color-danger">*</span></label>
                              <input type="text" id="desc" class="form__input" name="descripcion" value="<?php echo e($item->descripcion); ?>" placeholder="Descripcion">

                              <input type="hidden" id="id" class="form__input" name="id" value="<?php echo e($item->id); ?>">
                              <input type="hidden" id="id_categoria" class="form__input" name="id_categoria" value="<?php echo e($categoria[0]->id); ?>">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-1">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Tipo <span class="color-danger">*</span></label>
                              <input type="text" id="nomb" class="form__input" name="tipo" value="<?php echo e($item->tipo); ?>" placeholder="Tipo">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-2">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Observaciones <span class="color-danger">*</span></label>
                              <input type="text" id="nomb" class="form__input" name="observaciones" value="<?php echo e($item->observaciones); ?>" placeholder="Observaciones">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        <div class="flex-md-1">

                          <div class="form__group">
                              <label for="fname" class="form__label" id="opcional">Nivel <span class="color-danger">*</span></label>
                              <input type="number" id="nomb" class="form__input" name="nivel" value="<?php echo e($item->nivel); ?>" placeholder="Nivel">
                            </div><!-- .form__group ends -->

                        </div><!-- .flex-* ends -->
                        
        
                        <div class="flex-md-2">

                                          <br><button class="button" type="submit" name="submit">Actualizar</button>

                        </div><!-- .flex-* ends -->


                    </form> 
                    <form action="eliminart" enctype="multipart/form-data" method="POST">
                     <?php echo e(csrf_field()); ?>

                      <div class="flex-md-1">
                                          <input type="hidden" id="id" class="form__input" name="id" value="<?php echo e($item->id); ?>">
                                          <input type="hidden" id="id_categoria" class="form__input" name="id_categoria" value="<?php echo e($categoria[0]->id); ?>">
                                          <br><button class="button" type="submit" name="submit">Eliminar</button>

                        </div><!-- .flex-* ends -->
                    </form> 
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                
              
             <br><br><br>
            </div><!-- .flex-* ends -->
          </div><!-- .row ends -->
        </div><!-- .container ends -->
      </section>
      <!-- SECTION ENDS -->

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel2\laravel2\resources\views/actividad/tareas.blade.php ENDPATH**/ ?>