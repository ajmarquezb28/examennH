<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="base_url" content="<?php echo e(URL::to('/')); ?>">


    <!-- Main CSS -->
    <link href="dist/css/main.css" rel="stylesheet">

    <!-- Your page title -->
    <title>Actividades</title>

    <!-- Place Custom Favicon here -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/png">


  </head>

  <body>

    <div class="page-loader">
      <div class="loader"><img src="images/logo-sm.svg" alt=""></div>
    </div>

    <!-- =================== SITE HEADER BEGINS ============================= -->

    <header class="header transparent fixed light-text" data-onscroll-classes="dark-text white-bg"
      data-onscroll-logo="images/logo-dark.png">

      <div class="container">

        <nav class="header__nav bottom-nav">

         

          <div class="header__mobile--opener hide-on-lg">
            <button class="header__mobile--icon" aria-expanded="false" aria-controls="mobile-menu"
              data-toggle="mobile-menu">
              <span class="line"></span>
              <span class="line"></span>
              <span class="line"></span>
            </button>
          </div>

          <ul class="header__navitems show-on-lg" id="mobile-menu">

            <li class="header__list"><a href="inicio">Inicio</a></li>
            <!-- .header__list ends -->

            <li class="header__list"><a href="categorias">Categorías</a></li><!-- .header__list ends -->

            <!-- .header__list ends -->

          </ul><!-- .header__navitems ends -->

         

        </nav><!-- .header__nav ends -->

      </div><!-- .container ends -->

    </header><!-- .header ends -->

    <!-- =================== SITE HEADER ENDS ============================= -->



    <!-- =================== MAIN SECTION BEGINS ============================= -->

    <main>
        <!-- NEXT EVENT STARTS -->
      <div class="next-event default-section-spacing background-primary">

        <div class="container">

          <div class="row align-items-center">

            <div class="flex-md-9">

              <div class="intro fancy-font"><br></div>
              <div class="event">
                <div class="event__metas horizontal">
                  
               
                </div><!-- .event__metas -->

               
              </div><!-- .event ends -->

            </div><!-- .flex-* ends -->


          </div><!-- .row ends -->

        </div><!-- .container ends -->

      </div><!-- .next-event ends -->
      <!-- NEXT EVENT ENDS -->


                
                
            <?php echo $__env->yieldContent('content'); ?>

        </main><!-- main ends -->

    <!-- =================== MAIN SECTION ENDS ============================= -->


    <!-- SCROLL BACK TO TOP BEGINS -->
    <div class="scroll-to-top"><i class="ri-arrow-up-line"></i></div>
    <!-- SCROLL BACK TO TOP ENDS -->


    <!-- =================== SITE FOOTER BEGINS ============================= -->

    <footer class="footer">

      <div class="container">

        <div class="footer__top display-flex justify-align-center">

        </div><!-- .footer__top ends -->

        <div class="footer__bottom">

          <div class="row align-items-center">


            <div class="flex-md-6 flex-lg-4">

              <div class="footer__info copyright">&copy; 2022 Actividades</div>

            </div><!-- .flex-* ends -->

            <div class="flex-md-6 flex-lg-4">

              <div class="footer__info credit">Términos y condiciones <br> Políticas de privacidad</div>

            </div><!-- .flex-* ends -->

            <div class="flex-md-6 flex-lg-4">

              <div class="footer__info social">
                <span>Redes sociales</span>
                <div class="social__icons">
                  <a href=""><i class="ri-facebook-line"></i></a>
                  <a href=""><i class="ri-twitter-line"></i></a>
                  <a href=""><i class="ri-linkedin-line"></i></a>
                </div>
              </div>

            </div><!-- .flex-* ends -->

          </div><!-- .row ends -->

        </div><!-- .footer__top ends -->

      </div><!-- .container ends -->

    </footer><!-- footer ends -->

    <!-- =================== SITE FOOTER ENDS ============================= -->


    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <!-- loading in JQuery locally if CDN failed -->
    <script>window.jQuery || document.write('<script src="js/jquery.min.js">\x3C/script>')</script>
    <!-- Owl Carousel script -->

    <!-- JQuery Credit Card script -->
    <script src="js/plugins/jquery.card.js"></script>
    <!-- Animate On Scroll script -->
    <script src="js/plugins/aos.js"></script>
    <!-- Lightbox script -->
    <script src="js/plugins/lightbox.min.js"></script>
    <!-- Main (custom) script -->
    <script src="dist/js/main.min.js"></script>

  </body>

</html><?php /**PATH C:\laragon\www\laravel2\laravel2\resources\views/layout/app.blade.php ENDPATH**/ ?>