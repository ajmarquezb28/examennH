@extends('layout.app')
<link href="{{ URL::asset('/assets/css/entel/inicio.css')}}" rel="stylesheet">
<script src="https://code.jquery.com/jquery-2.2.2.min.js"></script>

@section('content')
        @php
                $page ='inicio';
        @endphp

<script type="text/javascript">
  $(document).ready(function() {

    $("#2student").hide();
    $("#3student").hide();


    $("#twostudents").click(function(event){
       
            $("#2student").show();
            $("#3student").hide();

        
    });

    $("#threestudents").click(function(event){
       
            $("#2student").show();
            $("#3student").show();
        
    });

    $("#onestudents").click(function(event){
       
            $("#2student").hide();
            $("#3student").hide();
        
    });


});
</script>

     
      <!-- CONTACT FORM STARTS -->
<form action="enviarformulario" enctype="multipart/form-data" method="POST">
    {{ csrf_field() }}
   
      <section class="contact default-section-spacing">

        <div class="container">

            <div class="row">

              <div class="flex-md-12 mar-b-sm">

                        <div class="form__group">
                          <label for="subject" class="form__label"><b>ST. KATHARINE DREXEL CATHOLIC CHURCH </b></label><br>
                          <label for="subject" class="form__label">RELIGIOUS EDUCATION REGISTRATION FORM FOR 2022-2023  </label>
                         
                        </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-12">

                <div class="form__group">
                    <div class="row">
                      <div class="flex-md-2 mar-b-sm">
                        <label for="html">Students Quantity</label><br>
                      </div>
                      <div class="flex-md-2 mar-b-sm">
                        <input type="radio" id="onestudents" name="students" value="1" checked required="required">
                        <label for="html">One students</label><br>
                      </div>
                      <div class="flex-md-2 mar-b-sm">
                        <input type="radio" id="twostudents" name="students" value="2" required="required">
                        <label for="css">Two students</label><br>
                      </div>
                      <div class="flex-md-2 mar-b-sm">
                        <input type="radio" id="threestudents" name="students" value="3" required="required">
                        <label for="css">Three students</label><br>
                      </div>
                    </div>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->


              <div class="flex-md-12">

                <div class="form__group">
                    <div class="row">
                      <div class="flex-md-2 mar-b-sm">
                        <label for="html">Type</label><br>
                      </div>
                      <div class="flex-md-2 mar-b-sm">
                        <input type="radio" id="firtscommunion" name="type" value="1" checked required="required">
                        <label for="css">Firts Communion</label><br>
                      </div>
                      <div class="flex-md-2 mar-b-sm">
                        <input type="radio" id="secondcommunion" name="type" value="2" required="required">
                        <label for="css">Scripture Class</label><br>
                      </div>
                    </div>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->


              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Date <span class="color-danger">*</span></label>
                  <input type="date" id="fini" class="form__input" name="fini" placeholder="Date"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Family Last Name <span class="color-danger">*</span></label>
                  <input type="text" id="lastname" class="form__input" name="lastname" placeholder="Family Last Name"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Primary Language <span class="color-danger">*</span></label>
                  <input type="text" id="planguague" class="form__input" name="planguague" placeholder="Primary Language"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Home Address <span class="color-danger">*</span></label>
                  <input type="text" id="homea" class="form__input" name="homea" placeholder="Home Address"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">City <span class="color-danger">*</span></label>
                  <input type="text" id="city" class="form__input" name="city" placeholder="City"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Zip <span class="color-danger">*</span></label>
                  <input type="text" id="zip" class="form__input" name="zip" placeholder="Zip"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Mother’s e-mail address <span class="color-danger">*</span></label>
                  <input type="email" id="emailmothers" class="form__input" name="emailmothers" placeholder="Mother’s e-mail address "  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Father’s e-mail address <span class="color-danger">*</span></label>
                  <input type="email" id="emailfathers" class="form__input" name="emailfathers" placeholder="Father’s e-mail address"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Father’s/Guardian Name <span class="color-danger">*</span></label>
                  <input type="text" id="gfather" class="form__input" name="gfather" placeholder="Father’s/Guardian Name"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Cell Phone <span class="color-danger">*</span></label>
                  <input type="number" id="cfather" class="form__input" name="cfather" placeholder=" Cell Phone "  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Religion <span class="color-danger">*</span></label>
                  <input type="text" id="rfathers" class="form__input" name="rfathers" placeholder="Religion"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Mother’s/Guardian Name<span class="color-danger">*</span></label>
                  <input type="text" id="gmother" class="form__input" name="gmother" placeholder="Mother’s/Guardian Name"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Cell Phone <span class="color-danger">*</span></label>
                  <input type="number" id="cmother" class="form__input" name="cfmoher" placeholder="Cell phone"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label">Religion <span class="color-danger">*</span></label>
                  <input type="text" id="rmothers" class="form__input" name="rmothers" placeholder="Religion"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

                <div class="flex-md-12 mar-b-sm">

                        <div class="form__group">
                          <br><label for="subject" class="form__label">Children live with (circle one): Both Parents, Mom, Dad, Other Marital Status (circle one): Married, Separated, Divorced, Other  </label>
                        </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-6">

                <div class="form__group">
                  <label for="fname" class="form__label"> Emergency Contact Name (other than parents): <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyp" class="form__input" name="emergencyp" placeholder="Emergency"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-6">

                <div class="form__group">
                  <label for="fname" class="form__label"> Cell Phone <span class="color-danger">*</span></label>
                  <input type="text" id="cemergencyp" class="form__input" name="cemergencyp" placeholder="Cell phone"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-12 mar-b-sm">

                        <div class="form__group">
                          <br><label for="subject" class="form__label">1.- Student</label>
                        </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Name: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyn" class="form__input" name="name_student" placeholder="Name"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Gender: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="boy" name="gender" value="Boy">
                  <label for="html">Boy</label><br>
                  <input type="radio" id="girl" name="gender" value="Girl">
                  <label for="css">Girl</label><br>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Religion: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyr" class="form__input" name="religion" placeholder="Religion"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Birthdate <span class="color-danger">*</span></label>
                  <input type="date" id="cemergencyb" class="form__input" name="birthdate" placeholder="Birthdate"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Place of Birth: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyplace" class="form__input" name="placebirth" placeholder="Place of Birth"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Is your child Baptized?: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="yes" name="isbat" value="Yes">
                  <label for="html">Yes</label><br>
                  <input type="radio" id="no" name="isbat" value="No">
                  <label for="css">No</label><br>
                </div><!-- .form__group ends -->


              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Received First Communion?: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="yes" name="iscom" value="Yes">
                  <label for="html">Yes</label><br>
                  <input type="radio" id="no" name="iscom" value="No">
                  <label for="css">No</label><br>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Grade in August 2022 <span class="color-danger">*</span></label>
                  <input type="text" id="grade2022" class="form__input" name="grade2022" placeholder="Grade in August 2022"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> School: <span class="color-danger">*</span></label>
                  <input type="text" id="school" class="form__input" name="school" placeholder="School"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Cell Phone <span class="color-danger">*</span></label>
                  <input type="text" id="cemergencyp" class="form__input" name="phonestudent" placeholder="Cell phone"  required="required">
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-12">

                <div class="form__group">
                  <br><label for="fname" class="form__label">Any physical, medical, or learning conditions please indicate below:</label><br>
                  <label for="fname" class="form__label"><b>SESSION: (Must indicate 1st, 2nd, and 3rd Choice) </b> </label><br>

              <div class="row">
                <div class="flex-md-4">
                  <input type="checkbox" id="1session" name="1session" value="1">
                  <label for="html">MONDAY 3:30 p.m - 4:45 p.m</label><br>
                  <input type="checkbox" id="2session" name="2session" value="2">
                  <label for="css">MONDAY 5:15 p.m - 6:30 p.m</label><br>
                  <input type="checkbox" id="3session" name="3session" value="3">
                  <label for="html">TUESDAY 3:30 p.m. - 4:45 p.m.</label><br>
                </div>
                <div class="flex-md-4">
                  <input type="checkbox" id="4session" name="4session" value="4">
                  <label for="css">TUESDAY 5:15 p.m. - 6:30 p.m.</label><br>
                  <input type="checkbox" id="5session" name="5session" value="5">
                  <label for="html">TUESDAY 6:45 p.m. - 8:00 p.m. </label><br>
                  <input type="checkbox" id="6session" name="6session" value="6">
                  <label for="css">WEDNESDAY 3:30 p.m. - 4:45 p.m.</label><br>
                </div>
                <div class="flex-md-4">
                  <input type="checkbox" id="7session" name="7session" value="7">
                  <label for="html">WEDNESDAY 5:15 p.m. - 6:30 p.m.</label><br>
                  <input type="checkbox" id="8session" name="8session" value="8">
                  <label for="css">THURSDAY 3:30 p.m. - 4:45 p.m.</label><br>
                  <input type="checkbox" id="9session" name="9session" value="9">
                  <label for="html">THURSDAY 5:15 p.m. - 6:30 p.m.</label><br>
                </div>
              </div>
          

                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->



              <div class="row" id="2student">
                <div class="flex-md-12 mar-b-sm">

                        <div class="form__group">
                          <br><label for="subject" class="form__label">2.- Student</label>
                        </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Name: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyn" class="form__input" name="name_student2" placeholder="Name"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Gender: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="boy" name="gender2" value="Boy">
                  <label for="html">Boy</label><br>
                  <input type="radio" id="girl" name="gender2" value="Girl">
                  <label for="css">Girl</label><br>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Religion: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyr" class="form__input" name="religion2" placeholder="Religion"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Birthdate <span class="color-danger">*</span></label>
                  <input type="date" id="cemergencyb" class="form__input" name="birthdate2" placeholder="Birthdate"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Place of Birth: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyplace" class="form__input" name="placebirth2" placeholder="Place of Birth"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Is your child Baptized?: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="yes" name="isbat2" value="Yes">
                  <label for="html">Yes</label><br>
                  <input type="radio" id="no" name="isbat2" value="No">
                  <label for="css">No</label><br>
                </div><!-- .form__group ends -->


              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Received First Communion?: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="yes" name="iscom2" value="Yes">
                  <label for="html">Yes</label><br>
                  <input type="radio" id="no" name="iscom2" value="No">
                  <label for="css">No</label><br>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Grade in August 2022 <span class="color-danger">*</span></label>
                  <input type="text" id="grade2022" class="form__input" name="grade20222" placeholder="Grade in August 2022"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> School: <span class="color-danger">*</span></label>
                  <input type="text" id="school" class="form__input" name="school2" placeholder="School"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Cell Phone <span class="color-danger">*</span></label>
                  <input type="text" id="cemergencyp" class="form__input" name="phonestudent2" placeholder="Cell phone"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-12">

                <div class="form__group">
                  <br><label for="fname" class="form__label">Any physical, medical, or learning conditions please indicate below:</label><br>
                  <label for="fname" class="form__label"><b>SESSION: (Must indicate 1st, 2nd, and 3rd Choice) </b> </label><br>

              <div class="row">
                <div class="flex-md-4">
                  <input type="checkbox" id="1session" name="1session2" value="1">
                  <label for="html">MONDAY 3:30 p.m - 4:45 p.m</label><br>
                  <input type="checkbox" id="2session" name="2session2" value="2">
                  <label for="css">MONDAY 5:15 p.m - 6:30 p.m</label><br>
                  <input type="checkbox" id="3session" name="3session2" value="3">
                  <label for="html">TUESDAY 3:30 p.m. - 4:45 p.m.</label><br>
                </div>
                <div class="flex-md-4">
                  <input type="checkbox" id="4session" name="4session2" value="4">
                  <label for="css">TUESDAY 5:15 p.m. - 6:30 p.m.</label><br>
                  <input type="checkbox" id="5session" name="5session2" value="5">
                  <label for="html">TUESDAY 6:45 p.m. - 8:00 p.m. </label><br>
                  <input type="checkbox" id="6session" name="6session2" value="6">
                  <label for="css">WEDNESDAY 3:30 p.m. - 4:45 p.m.</label><br>
                </div>
                <div class="flex-md-4">
                  <input type="checkbox" id="7session" name="7session2" value="7">
                  <label for="html">WEDNESDAY 5:15 p.m. - 6:30 p.m.</label><br>
                  <input type="checkbox" id="8session" name="8session2" value="8">
                  <label for="css">THURSDAY 3:30 p.m. - 4:45 p.m.</label><br>
                  <input type="checkbox" id="9session" name="9session2" value="9">
                  <label for="html">THURSDAY 5:15 p.m. - 6:30 p.m.</label><br>
                </div>
              </div>
          

                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->
              </div>

            

            <div class="row" id="3student">
                <div class="flex-md-12 mar-b-sm">

                        <div class="form__group">
                          <br><label for="subject" class="form__label">3.- Student</label>
                        </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Name: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyn" class="form__input" name="name_student3" placeholder="Name"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Gender: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="boy" name="gender3" value="Boy">
                  <label for="html">Boy</label><br>
                  <input type="radio" id="girl" name="gender3" value="Girl">
                  <label for="css">Girl</label><br>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Religion: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyr" class="form__input" name="religion3" placeholder="Religion"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Birthdate <span class="color-danger">*</span></label>
                  <input type="date" id="cemergencyb" class="form__input" name="birthdate3" placeholder="Birthdate"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Place of Birth: <span class="color-danger">*</span></label>
                  <input type="text" id="emergencyplace" class="form__input" name="placebirth3" placeholder="Place of Birth"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Is your child Baptized?: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="yes" name="isbat3" value="Yes">
                  <label for="html">Yes</label><br>
                  <input type="radio" id="no" name="isbat3" value="No">
                  <label for="css">No</label><br>
                </div><!-- .form__group ends -->


              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Received First Communion?: <span class="color-danger">*</span></label><br>
                  <input type="radio" id="yes" name="iscom3" value="Yes">
                  <label for="html">Yes</label><br>
                  <input type="radio" id="no" name="iscom3" value="No">
                  <label for="css">No</label><br>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Grade in August 2022 <span class="color-danger">*</span></label>
                  <input type="text" id="grade2022" class="form__input" name="grade20223" placeholder="Grade in August 2022"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> School: <span class="color-danger">*</span></label>
                  <input type="text" id="school" class="form__input" name="school3" placeholder="School"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-4">

                <div class="form__group">
                  <label for="fname" class="form__label"> Cell Phone <span class="color-danger">*</span></label>
                  <input type="text" id="cemergencyp" class="form__input" name="phonestudent3" placeholder="Cell phone"  >
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-12">

                <div class="form__group">
                  <br><label for="fname" class="form__label">Any physical, medical, or learning conditions please indicate below:</label><br>
                  <label for="fname" class="form__label"><b>SESSION: (Must indicate 1st, 2nd, and 3rd Choice) </b> </label><br>

              <div class="row">
                <div class="flex-md-4">
                  <input type="checkbox" id="1session" name="1session3" value="1">
                  <label for="html">MONDAY 3:30 p.m - 4:45 p.m</label><br>
                  <input type="checkbox" id="2session" name="2session3" value="2">
                  <label for="css">MONDAY 5:15 p.m - 6:30 p.m</label><br>
                  <input type="checkbox" id="3session" name="3session3" value="3">
                  <label for="html">TUESDAY 3:30 p.m. - 4:45 p.m.</label><br>
                </div>
                <div class="flex-md-4">
                  <input type="checkbox" id="4session" name="4session3" value="4">
                  <label for="css">TUESDAY 5:15 p.m. - 6:30 p.m.</label><br>
                  <input type="checkbox" id="5session" name="5session3" value="5">
                  <label for="html">TUESDAY 6:45 p.m. - 8:00 p.m. </label><br>
                  <input type="checkbox" id="6session" name="6session3" value="6">
                  <label for="css">WEDNESDAY 3:30 p.m. - 4:45 p.m.</label><br>
                </div>
                <div class="flex-md-4">
                  <input type="checkbox" id="7session" name="7session3" value="7">
                  <label for="html">WEDNESDAY 5:15 p.m. - 6:30 p.m.</label><br>
                  <input type="checkbox" id="8session" name="8session3" value="8">
                  <label for="css">THURSDAY 3:30 p.m. - 4:45 p.m.</label><br>
                  <input type="checkbox" id="9session" name="9session3" value="9">
                  <label for="html">THURSDAY 5:15 p.m. - 6:30 p.m.</label><br>
                </div>
              </div>
          

                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->
              </div>



              <div class="flex-md-12 mar-b-sm">

                <div class="form__group">
                  <br><label for="message-2" class="form__label"><b>Comments</b> <span class="color-danger">*</span></label>
                  <textarea name="descripcion" id="descripcion" class="form__textarea form__input"
                    placeholder="Enter your comments..."  ></textarea>
                </div><!-- .form__group ends -->

              </div><!-- .flex-* ends -->

              <div class="flex-md-12 mar-b-sm">

                <button class="button" type="submit" name="submit">Save and proceed to payment</button>

              </div><!-- .flex-* ends -->



            </div><!-- .row ends -->

        </div><!-- .container ends -->

      </section><!-- .contact ends -->
      <!-- CONTACT FORM ENDS -->
</form>
    

@endsection