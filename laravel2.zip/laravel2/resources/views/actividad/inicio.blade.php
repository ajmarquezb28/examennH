@extends('layout.app')
<link href="{{ URL::asset('/assets/css/actv/inicio.css')}}" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
@section('content')
        @php
                $page ='inicio';
        @endphp

        <!-- LAST SERMON SECTION STARTS -->
      <section class="default-section-spacing">

        <div class="container">

          <div class="row align-items-center">

            <div class="flex-md-12 flex-lg-12" align="center">

              <h2>Administracion de datos de las actividades</h2>

                <table class="table-responsive  table-sm">                
                      <tbody>
                        <tr class="table-warning">
                          <th scope="col" colspan="5">Categorías</th>
                        </tr>
                        <tr class="table-info">
                          <th scope="col">#</th>
                          <th scope="col">Nombre</th>
                          <th scope="col" colspan="2">Descripcion</th>
                          <th scope="col">Fecha</th>
                        </tr>
                      @foreach ($categoria as $item)
                        
                        <tr class="table-success">
                          <th scope="row">{{$item->id}}</th>
                          <td>{{$item->nombre}}</td>
                          <td colspan="2">{{$item->descripcion}}</td>
                          <td>{{$item->fecha_creacion}}</td>
                        </tr>
                        <tr class="table-warning">
                          <th scope="col">Nombre</th>
                          <th scope="col">Tipo</th>
                          <th scope="col">Descripcion</th>
                          <th scope="col">Observaciones</th>
                          <th scope="col">Nivel</th>
                          <th scope="col">Fecha</th>
                        </tr>
                        @foreach ($item->tareas as $values)
                        <tr class="table-danger">
                          <td>{{$values->nombre}}</td>
                          <td>{{$values->tipo}}</td>
                          <td>{{$values->descripcion}}</td>
                          <td>{{$values->observaciones}}</td>
                          <td>{{$values->nivel}}</td>
                          <td>{{$values->fecha_creacion}}</td>
                        </tr>
                        @endforeach
                      @endforeach
                      </tbody>
                </table><br><br><br>
                
              </div><!-- . ends -->

            </div><!-- .flex-* ends -->

          </div><!-- .row ends -->

        </div><!-- .container ends -->

      </section>
      <!-- SECTION ENDS -->

    

@endsection